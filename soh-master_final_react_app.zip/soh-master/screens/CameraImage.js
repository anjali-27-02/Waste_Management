import React, { useState, useEffect } from 'react';
import { StyleSheet, View, Image, TouchableOpacity, Dimensions, ActivityIndicator } from 'react-native';
import Cameras from '../component/Cameras'

export default function CameraImage() {


    return (

        <
        Cameras / >

    );
}



const styles = StyleSheet.create({});