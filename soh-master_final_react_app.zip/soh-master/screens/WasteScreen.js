
import { View, Text,StyleSheet } from 'react-native'
import React from 'react'
import tw from 'tailwind-react-native-classnames'
import NavOption5 from '../component/NavOption5';
import Map from '../component/Map';


const WasteScreen = () => {
  
  return (
    <View>
   
<NavOption5/>
    
    </View>
       
  )
}

export default WasteScreen